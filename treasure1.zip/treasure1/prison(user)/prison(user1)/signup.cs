﻿using prison_user2_;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prison_user1_
{
    public partial class signup : Form
    {
        public signup()
        {
            InitializeComponent();
        }
        private SqlConnection myconnection;
        

        private void button1_Click(object sender, EventArgs e)
        {
            
            string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=E:\PRISON\prison(user)\user.mdf;Integrated Security=True;Connect Timeout=30";
            myconnection = new SqlConnection(connectionString);
            try
            {
                string query = "INSERT into em1(Employeeid,Employeename,Password)values('" + textBox1.Text + "', '" + textBox2.Text + "', '" + textBox3.Text + "')";
                SqlCommand mycommand = new SqlCommand(query,myconnection);
                myconnection.Open();
                mycommand.ExecuteNonQuery();

                MessageBox.Show("Sucessful");
            }
            catch (Exception ex)
            {
                MessageBox.Show("error");
            }
            finally
            {
                myconnection.Close();
            }
        }
    }
}
